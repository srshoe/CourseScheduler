/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author srsho
 */
public class StudentQueries {
    private static Connection connection;
    private static PreparedStatement addClass;
    private static PreparedStatement getAllStudents;
    private static PreparedStatement dropStudent;
    private static ResultSet resultSet;
    
    
    public static void addStudent(StudentEntry student)
    {
        connection = DBConnection.getConnection();
        try 
        {
            addClass = connection.prepareStatement("INSERT INTO app.student (studentID, firstName, lastName) VALUES (?, ?, ?)");
            addClass.setString(1, student.getStudentID());
            addClass.setString(2, student.getFirstName());
            addClass.setString(3, student.getLastName());
            addClass.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    public static ArrayList<StudentEntry> getAllStudents()
    {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> allStudents = new ArrayList<StudentEntry>();
        try 
        {
            getAllStudents = connection.prepareStatement("SELECT * FROM app.student");
            resultSet = getAllStudents.executeQuery();
            
            while(resultSet.next())
            {
                allStudents.add(new StudentEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3)));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return allStudents;
    }
    public static void dropStudent(StudentEntry student)
    {
        connection = DBConnection.getConnection();
        try
        {
            dropStudent = connection.prepareStatement("DELETE FROM app.student WHERE studentID = ?");
            dropStudent.setString(1, student.getStudentID());
            dropStudent.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
}
