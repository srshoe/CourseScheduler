/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author srsho
 */
public class ScheduleQueries {
    private static Connection connection;
    private static PreparedStatement addScheduleEntry;
    private static PreparedStatement getScheduleByStudent;
    private static PreparedStatement getScheduledStudentCount;
    private static PreparedStatement dropStudentSchedule;
    private static PreparedStatement dropClassSchedule;
    private static PreparedStatement getWStudentIDFromCode;
    private static PreparedStatement changeStatus;
    private static ResultSet resultSet;
    
    public static void addScheduleEntry(ScheduleEntry entry)
    {
        connection = DBConnection.getConnection();
        try 
        {
            addScheduleEntry = connection.prepareStatement("INSERT INTO app.schedule(semester, coursecode, studentID, status, timestamp) VALUES (?, ?, ?, ?, ?)");
            addScheduleEntry.setString(1, entry.getSemester());
            addScheduleEntry.setString(2, entry.getCourseCode());
            addScheduleEntry.setString(3, entry.getStudentID());
            addScheduleEntry.setString(4, entry.getStatus());
            addScheduleEntry.setTimestamp(5, entry.getTimestamp());
            
            addScheduleEntry.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID)
    {
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> studentSchedules = new ArrayList<ScheduleEntry>();
        try
        {
            getScheduleByStudent = connection.prepareStatement("SELECT * FROM app.schedule WHERE semester = ? and studentID = ? ORDER BY courseCode");
            getScheduleByStudent.setString(1, semester);
            getScheduleByStudent.setString(2, studentID);
            
            resultSet = getScheduleByStudent.executeQuery();
            while(resultSet.next())
            {
                studentSchedules.add(new ScheduleEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getTimestamp(5)));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return studentSchedules;
    }
    public static int getScheduledStudentCount(String currentSemester, String courseCode)
    {
        connection = DBConnection.getConnection();
        int count = 0;
        try
        {
            getScheduledStudentCount = connection.prepareStatement("SELECT count(studentID) from app.schedule where semester = ? and courseCode = ? and status = 'Scheduled'");
            getScheduledStudentCount.setString(1, currentSemester);
            getScheduledStudentCount.setString(2, courseCode);
            
            resultSet = getScheduledStudentCount.executeQuery();
            
            while(resultSet.next())
            {
                count = resultSet.getInt(1);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return count;
    }
    public static void dropStudentSchedule(StudentEntry student)
    {
        connection = DBConnection.getConnection();
        try 
        {
            dropStudentSchedule = connection.prepareStatement("DELETE FROM app.schedule WHERE studentID = ?");
            dropStudentSchedule.setString(1, student.getStudentID());
            dropStudentSchedule.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    public static String getWStudentIDFromCode(String semester, String courseCode)
    {
        ArrayList<String> ids = new ArrayList<String>();
        connection = DBConnection.getConnection();
        String id;
        try 
        {
            getWStudentIDFromCode = connection.prepareStatement("SELECT studentID FROM app.schedule WHERE status = ? and semester = ? and courseCode = ? ORDER BY timestamp DESC");
            getWStudentIDFromCode.setString(1, "Waitlisted");
            getWStudentIDFromCode.setString(2, semester);
            getWStudentIDFromCode.setString(3, courseCode);
            resultSet = getWStudentIDFromCode.executeQuery();
            
            while (resultSet.next())
            {
                ids.add(resultSet.getString(1));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        if (ids.size() != 0)
        {
            return ids.get(0);
        }
        return "";
    }
    public static void changeStatus(String id)
    {
        connection = DBConnection.getConnection();
        try 
        {
            changeStatus = connection.prepareStatement("UPDATE app.schedule SET status = 'Scheduled' WHERE studentid = ?");
            changeStatus.setString(1, id);
            changeStatus.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    public static void dropClassSchedule(String courseCode, String semester)
    {
        connection = DBConnection.getConnection();
        try 
        {
            dropClassSchedule = connection.prepareStatement("DELETE FROM app.schedule WHERE courseCode = ? and semester = ?");
            dropClassSchedule.setString(1, courseCode);
            dropClassSchedule.setString(2, semester);
            dropClassSchedule.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    public static void dropClassBasedOnStudent(StudentEntry student, String semester, String courseCode)
    {
        
        connection = DBConnection.getConnection();
        try 
        {
            dropClassSchedule = connection.prepareStatement("DELETE FROM app.schedule WHERE studentid = ? and courseCode = ? and semester = ?");
            dropClassSchedule.setString(1, student.getStudentID());
            dropClassSchedule.setString(2, courseCode);
            dropClassSchedule.setString(3, semester);
            dropClassSchedule.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
}
