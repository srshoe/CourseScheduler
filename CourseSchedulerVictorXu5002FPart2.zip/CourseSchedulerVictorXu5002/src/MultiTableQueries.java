/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author srsho
 */
public class MultiTableQueries {
    private static Connection connection;
    private static PreparedStatement getAllClassDescriptions;
    private static PreparedStatement getStudentsFromClass;
    private static ResultSet resultSet;
    
    public static ArrayList<ClassDescription> getAllClassDescriptions(String semester)
    {
        connection = DBConnection.getConnection();
        ArrayList<ClassDescription> classDescriptions = new ArrayList<ClassDescription>();
        try
        {
            getAllClassDescriptions = connection.prepareStatement("SELECT app.class.courseCode, description, seats FROM app.class, app.course WHERE semester = ? and app.class.courseCode = app.course.courseCode ORDER BY app.class.courseCode" );
            getAllClassDescriptions.setString(1, semester);
            resultSet = getAllClassDescriptions.executeQuery();
            
            while(resultSet.next())
            {
                classDescriptions.add(new ClassDescription(resultSet.getString(1), resultSet.getString(2), resultSet.getInt(3)));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return classDescriptions;
    }
    public static ArrayList<StudentEntry> getStudents(String semester, String courseCode)
    {
        ArrayList<StudentEntry> studentsInfo = new ArrayList<StudentEntry>();
        connection = DBConnection.getConnection();
        semester = semester.trim();
        courseCode = courseCode.trim();
        try
        {
            getStudentsFromClass = connection.prepareStatement("SELECT app.student.studentid, app.student.firstname, app.student.lastname FROM app.student, app.schedule WHERE app.schedule.studentID = app.student.studentID AND app.schedule.semester = ? AND app.schedule.courseCode = ?");
            getStudentsFromClass.setString(1, semester);
            getStudentsFromClass.setString(2, courseCode);
            resultSet = getStudentsFromClass.executeQuery();
            while(resultSet.next())
            {
                studentsInfo.add(new StudentEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3)));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return studentsInfo;
    }
}
